package com.project.LensMart2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LensMart2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
