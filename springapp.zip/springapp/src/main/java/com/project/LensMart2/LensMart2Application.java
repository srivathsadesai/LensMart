package com.project.LensMart2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LensMart2Application {

	public static void main(String[] args) {
		SpringApplication.run(LensMart2Application.class, args);
	}

}
