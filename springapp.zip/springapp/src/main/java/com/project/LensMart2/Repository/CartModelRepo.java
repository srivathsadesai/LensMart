package com.project.LensMart2.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.LensMart2.Entity.CartModel;

@Repository
public interface CartModelRepo extends JpaRepository<CartModel, Integer> {

	
}
